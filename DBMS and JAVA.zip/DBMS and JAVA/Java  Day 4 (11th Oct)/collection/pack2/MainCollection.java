package pack2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainCollection {

public static void main(String[] args) {
String choice=null;
Scanner sc = new Scanner(System.in);
ArrayList<Book>  bookList = new ArrayList<>();
do{
System.out.println("Enter book information:");
String data = sc.nextLine();
String a[] = data.split(",");
Book book = new Book(a[0], a[1], Double.parseDouble(a[2]));
bookList.add(book);
System.out.println("Continue?YES/NO");
choice = sc.nextLine();
}while(choice.equalsIgnoreCase("YES"));

//Collections.sort(bookList);
Collections.sort(bookList , new PriceComparator());
for(Book b:bookList){
	System.out.println(b.getBookName()+" "+b.getAuthorName()
	                   +" " + b.getPrice());
}
sc.close();


	}
}
