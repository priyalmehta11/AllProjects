package pack1;

import java.util.ArrayList;
import java.util.Scanner;

public class MainCollection {

public static void main(String[] args) {
String choice=null;
Scanner sc = new Scanner(System.in);
ArrayList<Book>  bookList = new ArrayList<>();
do{
System.out.println("Enter book information:");
String data = sc.nextLine();
String a[] = data.split(",");
Book book = new Book(a[0], a[1], Double.parseDouble(a[2]));
bookList.add(book);
System.out.println("Continue?YES/NO");
choice = sc.nextLine();
}while(choice.equalsIgnoreCase("YES"));

for(Book b:bookList){
/*for(int i=0; i<bookList.size();i++){
	Book b = bookList.get(i);*/
	System.out.println(b.getBookName()+" "+b.getAuthorName()
	                   +" " + b.getPrice());
}
sc.close();

Book b = bookList.get(0);
System.out.println(b.getBookName()+" "+b.getAuthorName()
+" " + b.getPrice());
b = bookList.get(bookList.size()-1);
System.out.println(b.getBookName()+" "+b.getAuthorName()
+" " + b.getPrice());

	}
}
