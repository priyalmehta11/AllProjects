package pack1;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertTest2 {

public static void main(String[] args)  {
Connection connection =null;
try {
Scanner sc = new Scanner(System.in);
System.out.println("Enter Student Id:");
int id = Integer.parseInt(sc.nextLine());
System.out.println("Enter Student Name:");
String name= sc.nextLine();
System.out.println("Enter Total Marks:");
int total = Integer.parseInt(sc.nextLine());

Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
connection = DriverManager.getConnection(
			"jdbc:oracle:thin:@localhost:1521:xe",
			"hr",
			"hr"); // step-2

PreparedStatement pst = connection.prepareStatement(
		"insert into student values (?,?,?)");
pst.setInt(1, id); 
pst.setString(2, name); 
pst.setInt(3, total);

int r= pst.executeUpdate();

System.out.println("Record is added :"+r);
} 
catch (ClassNotFoundException e) { System.out.println(e);}
catch (SQLException e) { System.out.println(e);}
finally{
	try {
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}// step-5
}

  } 



}
