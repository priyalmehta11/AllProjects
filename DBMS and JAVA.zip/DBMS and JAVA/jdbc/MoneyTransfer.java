package pack1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class MoneyTransfer {

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("From:");
			int from = Integer.parseInt(sc.nextLine());
			System.out.println("To:");
			int to = Integer.parseInt(sc.nextLine());
			System.out.println("Amount:");
			int amt = Integer.parseInt(sc.nextLine());

			Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
			Connection con = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"hr",
						"hr"); // step-2	
	con.setAutoCommit(false);
	PreparedStatement pst1 = con.prepareStatement(
			"update accounts set balance=balance-? where acno=?");
	pst1.setInt(1, amt); pst1.setInt(2, from);
	int a=pst1.executeUpdate();
	
	PreparedStatement pst2 = con.prepareStatement(
			"update accounts set balance=balance+? where acno=?");
	pst2.setInt(1, amt); pst2.setInt(2, to);
	int b=pst2.executeUpdate();
	
	if(a==1 && b==1)
		 con.commit();
	else
		con.rollback();
	con.close();
	}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
