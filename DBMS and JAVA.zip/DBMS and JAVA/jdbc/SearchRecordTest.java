package pack1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SearchRecordTest {

	public static void main(String[] args) {
		Connection connection =null;
		try {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Id:");
		int id = Integer.parseInt(sc.nextLine());
	

		Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
		connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"hr",
					"hr"); // step-2
 PreparedStatement pst = connection.prepareStatement(
		 "select * from student where studentid=?"); 
 pst.setInt(1,id);
 ResultSet rs = pst.executeQuery();
 if(rs.next()){
	 int tot = rs.getInt(3);
	 System.out.println("Name: "+rs.getString(2));
	 System.out.println("Total: "+tot);
	 System.out.println(tot>=200?"Pass":"Fail");
 }
 else
	 System.out.println("Record is not found");
	
		} 
		catch (ClassNotFoundException e) { System.out.println(e);}
		catch (SQLException e) { System.out.println(e);}
		finally{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}// step-5
		}
		

	}

}
