package pack1;

public class MyThread1 extends Thread {

	public MyThread1(String a){super(a);}

	public void run(){
		for( int i=1 ; i<=10; i++){
			System.out.println(i+  "  " + getName() );
			try{ sleep(1000);}  
			catch(Exception e){}
		}
	}
	public static void main(String[] args) {
		MyThread1 th1 = new MyThread1("AAAA"); th1.start();
		MyThread1 th2 = new MyThread1("BBBB"); th2.start();
	}
}

