package pack1;

class Printer {
	 public  void print(String name){
		 System.out.println("["+name + " starts print");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("]");
	 }
}

class User extends Thread{  String uname; Printer p;

public User(String uname, Printer p) {
	super();	this.uname = uname;	this.p = p; }

public void run() {
	synchronized(p){ p.print(uname); }
}
    
}
public class Main{
	 public static void main(String arg[]){
		 Printer pr = new Printer();
		 User u1 = new User("Jack",pr);
		 User u2 = new User("Jill",pr);
		 u1.start(); u2.start();
	 }
}

