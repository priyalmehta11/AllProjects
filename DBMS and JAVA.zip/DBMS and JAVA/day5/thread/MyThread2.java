package pack1;

public class MyThread2 implements Runnable{  Thread t;
public MyThread2(String a){
	t = new Thread(this,a); 
	t.start(); }
	public void run(){
	for( int i=1 ; i<=5; i++){
		System.out.println(i+  "  " + t.getName() );
		try{ t.sleep(1000);}  
		catch( InterruptedException e){ }
	}
}
public static void main(String[] args) {
	MyThread2 th1 = new MyThread2("AAAA"); 
	MyThread2 th2 = new MyThread2("BBBB"); 
}
}
