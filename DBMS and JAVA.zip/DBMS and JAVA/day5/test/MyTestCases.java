package pack2;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyTestCases {
    @Test
	public void test1(){
		Calculator ca = new Calculator();
		int res =ca.add(12, 23);
		//assertEquals(35, res);
		assertEquals(30, res);
		
	}
}
