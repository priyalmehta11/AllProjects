package pack2;

import org.junit.Test;
import static org.junit.Assert.*;
public class MyTestCase2 {

	@Test
	public void test1(){
		Calculator c = new Calculator();
		boolean flag=c.evenCheck(13);
		//assertTrue(flag);
		assertEquals(false, flag);
		
	}
}
