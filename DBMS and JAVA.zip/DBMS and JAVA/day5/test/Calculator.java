package pack2;

public class Calculator {
   public int add( int a, int b){
	   return a+b;
   }
   
   public boolean evenCheck(int n){
	   if(n%2==0)
		   return true;
	   else
		   return false;
   }
}
